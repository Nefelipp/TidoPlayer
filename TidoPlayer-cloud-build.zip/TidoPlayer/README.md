# Tido Player 2.1

Android client for the Tido Eclipse-compatible addon.

Tido base URL:
https://tido.tido.tido.dpdns.org/720298f32650412aacfb4b2d2b7b1acc

Features:
- Tido search (`/search`)
- Stream resolution (`/stream/{id}`)
- Album browsing (`/album/{id}`)
- Artist browsing (`/artist/{id}`)
- Quality selector passed as `quality` query parameter
- Media3 playback and background service
- Favorites with title/artist metadata

Build in Android Studio or AndroidIDE with:
`./gradlew :app:assembleDebug`

Note: this project does not bypass authentication, DRM, or server restrictions. It only consumes HTTP/HTTPS JSON and stream URLs exposed by the addon.
