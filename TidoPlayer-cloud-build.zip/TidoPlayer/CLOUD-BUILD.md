# Tido Player — cloud build

This copy is prepared to build the APK on GitHub Actions instead of on an Android tablet.

The workflow uses JDK 17, Android SDK 35, and Gradle 8.9, then uploads the generated debug APK as a workflow artifact.

No Tido credentials or DRM bypass code is included.
