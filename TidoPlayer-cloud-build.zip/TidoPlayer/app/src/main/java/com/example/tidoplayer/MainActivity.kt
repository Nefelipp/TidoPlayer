package com.example.tidoplayer

import android.content.ComponentName
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private val base = "https://tido.tido.tido.dpdns.org/720298f32650412aacfb4b2d2b7b1acc"
    private var quality = "HIRES"
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val favorites = linkedSetOf<String>()
    private val favoriteMeta = linkedMapOf<String, Pair<String, String>>()
    private lateinit var results: LinearLayout
    private lateinit var status: TextView
    private lateinit var nowPlaying: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture!!.addListener({ controller = controllerFuture!!.get() }, mainExecutor)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 20, 20, 12) }
        val title = TextView(this).apply { text = "Tido Player"; textSize = 28f; gravity = Gravity.CENTER_VERTICAL }
        root.addView(title, LinearLayout.LayoutParams(-1, 58))

        val qualitySpinner = Spinner(this)
        qualitySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Max Hi-Res", "Max + Dolby Atmos", "Lossless", "High AAC", "Low AAC"))
        qualitySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, pos: Int, id: Long) {
                quality = arrayOf("HIRES", "MAX", "LOSSLESS", "HIGH", "LOW")[pos]
            }
        }
        root.addView(qualitySpinner)

        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val query = EditText(this).apply { hint = "Search songs, albums, artists"; singleLine = true }
        searchRow.addView(query, LinearLayout.LayoutParams(0, -2, 1f))
        val search = Button(this).apply { text = "Search" }
        searchRow.addView(search)
        root.addView(searchRow)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val favButton = Button(this).apply { text = "Favorites" }
        val stopButton = Button(this).apply { text = "Stop" }
        nav.addView(favButton, LinearLayout.LayoutParams(0, -2, 1f)); nav.addView(stopButton, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(nav)

        status = TextView(this).apply { text = "Ready" }
        nowPlaying = TextView(this).apply { text = "Nothing playing"; textSize = 16f }
        root.addView(status); root.addView(nowPlaying)

        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(results) }, LinearLayout.LayoutParams(-1, 0, 1f))

        search.setOnClickListener { doSearch(query.text.toString()) }
        query.setOnEditorActionListener { _, _, _ -> doSearch(query.text.toString()); true }
        favButton.setOnClickListener { showFavorites() }
        stopButton.setOnClickListener { controller?.stop(); nowPlaying.text = "Nothing playing" }
        setContentView(root)
    }

    private fun request(path: String, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        client.newCall(Request.Builder().url("$base$path").build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = runOnUiThread { onError(e.message ?: "Network error") }
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) runOnUiThread { onError("HTTP ${response.code}") }
                else runOnUiThread { onSuccess(body) }
            }
        })
    }

    private fun doSearch(q: String) {
        if (q.isBlank()) return
        status.text = "Searching…"; results.removeAllViews()
        request("/search?q=${URLEncoder.encode(q, "UTF-8")}&quality=$quality", { renderSearch(it) }, { status.text = "Error: $it" })
    }

    private fun renderSearch(body: String) {
        try {
            val o = JSONObject(body); val tracks = o.optJSONArray("tracks") ?: JSONArray()
            val albums = o.optJSONArray("albums") ?: JSONArray(); val artists = o.optJSONArray("artists") ?: JSONArray()
            status.text = "${tracks.length()} tracks • ${albums.length()} albums • ${artists.length()} artists"
            for (i in 0 until tracks.length()) {
                val t = tracks.getJSONObject(i); addTrack(t)
            }
            for (i in 0 until albums.length()) addDetailButton("💿 ${albums.getJSONObject(i).optString("title")}", "album", albums.getJSONObject(i).optString("id"))
            for (i in 0 until artists.length()) addDetailButton("👤 ${artists.getJSONObject(i).optString("name")}", "artist", artists.getJSONObject(i).optString("id"))
        } catch (e: Exception) { status.text = "Invalid response: ${e.message}" }
    }

    private fun addTrack(t: JSONObject) {
        val id = t.optString("id"); val title = t.optString("title"); val artist = t.optString("artist")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val play = Button(this).apply { text = "▶ $title — $artist"; setOnClickListener { playTrack(id, title, artist) } }
        val fav = Button(this).apply { text = if (favorites.contains(id)) "♥" else "♡"; setOnClickListener {
            if (!favorites.add(id)) { favorites.remove(id); favoriteMeta.remove(id) } else { favoriteMeta[id] = title to artist }; text = if (favorites.contains(id)) "♥" else "♡"
        } }
        row.addView(play, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(fav, LinearLayout.LayoutParams(60, -2)); results.addView(row)
    }

    private fun addDetailButton(label: String, type: String, id: String) {
        if (id.isBlank()) return
        results.addView(Button(this).apply { text = label; setOnClickListener { loadDetail(type, id) } })
    }

    private fun loadDetail(type: String, id: String) {
        status.text = "Loading $type…"; results.removeAllViews()
        request("/$type/${URLEncoder.encode(id, "UTF-8")}", { body ->
            try {
                val o = JSONObject(body)
                if (type == "album") {
                    status.text = "Album: ${o.optString("title")}"; val tracks = o.optJSONArray("tracks") ?: JSONArray();
                    for (i in 0 until tracks.length()) addTrack(tracks.getJSONObject(i))
                } else {
                    status.text = "Artist: ${o.optString("name")}"; val tracks = o.optJSONArray("topTracks") ?: JSONArray();
                    for (i in 0 until tracks.length()) addTrack(tracks.getJSONObject(i))
                }
            } catch (e: Exception) { status.text = "Detail error: ${e.message}" }
        }, { status.text = "$type error: $it" })
    }

    private fun playTrack(id: String, title: String, artist: String) {
        status.text = "Resolving $title…"
        request("/stream/${URLEncoder.encode(id, "UTF-8")}?quality=$quality", { body ->
            try {
                val o = JSONObject(body); val url = o.optString("url")
                if (url.isBlank()) throw Exception("No stream URL returned")
                val item = MediaItem.Builder().setUri(url).setMediaId(id).setTag("$title — $artist").build()
                controller?.setMediaItem(item); controller?.prepare(); controller?.play()
                nowPlaying.text = "▶ $title — $artist"; status.text = "Playing • ${o.optString("quality", quality)}"
            } catch (e: Exception) { status.text = "Stream error: ${e.message}" }
        }, { status.text = "Stream error: $it" })
    }

    private fun showFavorites() {
        results.removeAllViews(); status.text = "Favorites: ${favorites.size}"
        if (favorites.isEmpty()) { results.addView(TextView(this).apply { text = "No favorites yet."; textSize = 18f }); return }
        favorites.forEach { id ->
            val meta = favoriteMeta[id]
            val label = if (meta != null) "♥ ${meta.first} — ${meta.second}" else "♥ $id"
            results.addView(Button(this).apply { text = label; setOnClickListener { playTrack(id, meta?.first ?: id, meta?.second ?: "") } })
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}
